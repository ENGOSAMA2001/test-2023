<?php
function wb_ebaic_hrlp_support_notice() {
?>
	<div class="notice notice-info is-dismissible">
		<h3>Before After Image Comparison Slider for Elementor</h3>
		<p class="wb-ebaic-font-16">Facing Problem or need your Custom Project Done? Don't hesitate to contact with our support team. Just send us an email at <a class=" wb-ebaic-bold text-decoration-none" href='mailto:webbuilders03@gmail.com'><strong>webbuilders03@gmail.com</strong></a> </p>.
	</div>
<?php
}
//add_action( 'admin_notices', 'wb_ebaic_hrlp_support_notice' );